<?php
namespace app\controllers;
use app\models\User;
class UserController {
    private $m;
    public function __construct(){ $this->m = new User(); }
    public function handle($path){
        if(!isset($_SESSION['user'])) { header('Location: ' . BASE_URL . 'login'); exit; }
        if($_SESSION['user']['role'] !== 'admin'){ echo 'Access denied'; exit; }
        if($path === 'users' ){
            $users = $this->m->all();
            require __DIR__ . '/../views/users/index.php';
        } elseif($path === 'users/create' && $_SERVER['REQUEST_METHOD']==='GET'){
            require __DIR__ . '/../views/users/create.php';
        } elseif($path === 'users/store' && $_SERVER['REQUEST_METHOD']==='POST'){
            $this->m->create($_POST);
            header('Location: ' . BASE_URL . 'users');
        } elseif($path === 'users/edit' && isset($_GET['id'])){
            $user = $this->m->find($_GET['id']);
            require __DIR__ . '/../views/users/edit.php';
        } elseif($path === 'users/update' && $_SERVER['REQUEST_METHOD']==='POST' && isset($_GET['id'])){
            $this->m->update($_GET['id'], $_POST);
            header('Location: ' . BASE_URL . 'users');
        } elseif($path === 'users/delete' && isset($_GET['id'])){
            $this->m->delete($_GET['id']);
            header('Location: ' . BASE_URL . 'users');
        } else {
            echo '404 users';
        }
    }
}
