<?php
namespace app\controllers;
use app\models\Vehicle;
class DashboardController {
    public function index(){
        if(!isset($_SESSION['user'])) { header('Location: ' . BASE_URL . 'login'); exit; }
        $vehicles = (new Vehicle())->all();
        require __DIR__ . '/../views/dashboard/index.php';
    }
}
