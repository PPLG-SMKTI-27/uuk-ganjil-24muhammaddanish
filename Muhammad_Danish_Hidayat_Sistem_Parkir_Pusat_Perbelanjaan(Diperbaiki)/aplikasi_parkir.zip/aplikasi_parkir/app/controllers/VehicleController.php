<?php
namespace app\controllers;
use app\models\Vehicle;
class VehicleController {
    private $m;
    public function __construct(){ $this->m = new Vehicle(); }
    public function handle($path){
        if(!isset($_SESSION['user'])) { header('Location: ' . BASE_URL . 'login'); exit; }
        if($path === 'vehicles'){
            $vehicles = $this->m->all();
            require __DIR__ . '/../views/vehicles/index.php';
        } elseif($path === 'vehicles/create' && $_SERVER['REQUEST_METHOD']==='GET'){
            require __DIR__ . '/../views/vehicles/create.php';
        } elseif($path === 'vehicles/store' && $_SERVER['REQUEST_METHOD']==='POST'){
            $_POST['created_by'] = $_SESSION['user']['id'];
            $this->m->create($_POST);
            header('Location: ' . BASE_URL . 'vehicles');
        } elseif($path === 'vehicles/edit' && isset($_GET['id'])){
            $vehicle = $this->m->find($_GET['id']);
            require __DIR__ . '/../views/vehicles/edit.php';
        } elseif($path === 'vehicles/update' && $_SERVER['REQUEST_METHOD']==='POST' && isset($_GET['id'])){
            $this->m->update($_GET['id'], $_POST);
            header('Location: ' . BASE_URL . 'vehicles');
        } elseif($path === 'vehicles/exit' && isset($_GET['id'])){
            $this->m->exitVehicle($_GET['id']);
            header('Location: ' . BASE_URL . 'vehicles');
        } elseif($path === 'vehicles/delete' && isset($_GET['id'])){
            $this->m->delete($_GET['id']);
            header('Location: ' . BASE_URL . 'vehicles');
        } else {
            echo '404 vehicles';
        }
    }
}
