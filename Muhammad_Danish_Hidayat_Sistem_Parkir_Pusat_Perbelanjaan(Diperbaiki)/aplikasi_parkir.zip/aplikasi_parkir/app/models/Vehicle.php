<?php
namespace app\models;
class Vehicle extends BaseModel {
    protected $table = 'vehicles';
    public function all(){
        $stmt = $this->db->query("SELECT v.*, u.username as created_by_name FROM vehicles v LEFT JOIN users u ON v.created_by = u.id ORDER BY v.id DESC");
        return $stmt->fetchAll();
    }
    public function create($data){
        $stmt = $this->db->prepare("INSERT INTO vehicles (plate,type,entry_time,created_by) VALUES (?, ?, NOW(), ?)");
        return $stmt->execute([$data['plate'],$data['type'],$data['created_by']]);
    }
    public function find($id){
        $stmt = $this->db->prepare("SELECT * FROM vehicles WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }
    public function update($id,$data){
        $stmt = $this->db->prepare("UPDATE vehicles SET plate=?, type=? WHERE id=?");
        return $stmt->execute([$data['plate'],$data['type'],$id]);
    }
    public function exitVehicle($id){
        $v = $this->find($id);
        if(!$v || $v['exit_time']) return false;
        $fee = ($v['type'] === 'motor') ? 5000 : 10000;
        $stmt = $this->db->prepare("UPDATE vehicles SET exit_time = NOW(), fee = ? WHERE id = ?");
        return $stmt->execute([$fee,$id]);
    }
    public function delete($id){
        $stmt = $this->db->prepare("DELETE FROM vehicles WHERE id = ?");
        return $stmt->execute([$id]);
    }
}
