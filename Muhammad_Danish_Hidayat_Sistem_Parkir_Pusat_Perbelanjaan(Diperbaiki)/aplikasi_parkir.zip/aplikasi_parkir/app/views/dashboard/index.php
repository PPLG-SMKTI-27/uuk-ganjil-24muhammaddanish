<?php require __DIR__ . '/../layout/header.php'; ?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <h3>Dashboard</h3>
  <div>
    <a class="btn btn-success" href="<?= BASE_URL ?>vehicles/create">+ Tambah Kendaraan</a>
  </div>
</div>
<div class="card shadow-sm">
  <div class="card-body">
    <table class="table table-striped table-bordered">
      <thead><tr><th>ID</th><th>Plat</th><th>Tipe</th><th>Masuk</th><th>Keluar</th><th>Biaya</th><th>Aksi</th></tr></thead>
      <tbody>
        <?php foreach($vehicles as $v): ?>
          <tr>
            <td><?= $v['id'] ?></td>
            <td><?= htmlspecialchars($v['plate']) ?></td>
            <td><?= $v['type'] ?></td>
            <td><?= $v['entry_time'] ?></td>
            <td><?= $v['exit_time'] ?: '-' ?></td>
            <td><?= $v['fee'] ? 'Rp '.number_format($v['fee'],0,',','.') : '-' ?></td>
            <td>
              <?php if(!$v['exit_time']): ?>
                <a class="btn btn-primary btn-sm" href="<?= BASE_URL ?>vehicles/exit?id=<?= $v['id'] ?>">Keluar</a>
              <?php endif; ?>
              <a class="btn btn-warning btn-sm" href="<?= BASE_URL ?>vehicles/edit?id=<?= $v['id'] ?>">Edit</a>
              <a class="btn btn-danger btn-sm" href="<?= BASE_URL ?>vehicles/delete?id=<?= $v['id'] ?>" onclick="return confirm('Hapus?')">Hapus</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php require __DIR__ . '/../layout/footer.php'; ?>
